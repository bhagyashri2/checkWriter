var app= angular.module('myapp',[]);
		app.controller('puzzleController',function($scope,$http){
		});